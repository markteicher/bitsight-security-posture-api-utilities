#!/usr/bin/env python3
import os
import csv
import json
import time
import logging
import requests
from tqdm import tqdm

# =========================
# Configuration
# =========================
API_BASE = os.getenv("BITSIGHT_BASE_URL", "https://api.bitsighttech.com")
# Typical pattern for BitSight risk vectors is company-scoped; set your company GUID here:
COMPANY_GUID = os.getenv("BITSIGHT_COMPANY_GUID", "PUT_COMPANY_GUID")
ENDPOINT = os.getenv("BITSIGHT_RISK_ENDPOINT", f"/ratings/v1/companies/{COMPANY_GUID}/risk_vectors")
ACCESS_KEY = os.getenv("BITSIGHT_ACCESS_KEY", "PUT_YOUR_ACCESS_KEY")
SECRET_KEY = os.getenv("BITSIGHT_SECRET_KEY", "PUT_YOUR_SECRET_KEY")
PROXIES = {
    "http": "http://vzproxy.verizon.com:9290",
    "https": "http://vzproxy.verizon.com:9290"
}
OUTPUT_FILE = "bitsight_risk_vectors.csv"

# =========================
# Logging
# =========================
logging.basicConfig(
    filename="risk_vectors.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
console.setFormatter(logging.Formatter("%(message)s"))
logging.getLogger().addHandler(console)

def flatten(obj, parent_key="", sep="_"):
    items = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            items.extend(flatten(v, new_key, sep=sep).items())
    elif isinstance(obj, list):
        items.append((parent_key, json.dumps(obj, separators=(",", ":"))))
    else:
        items.append((parent_key, obj))
    return dict(items)

def get_next_link(payload, base_url):
    if isinstance(payload, dict):
        nxt = payload.get("next")
        if nxt:
            return nxt if str(nxt).startswith("http") else base_url.rstrip("/") + "/" + str(nxt).lstrip("/")
        links = payload.get("links") or payload.get("_links") or {}
        if isinstance(links, dict):
            nxt = links.get("next") or links.get("next_url")
            if nxt:
                return nxt if str(nxt).startswith("http") else base_url.rstrip("/") + "/" + str(nxt).lstrip("/")
    return None

def extract_rows(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        if isinstance(payload.get("results"), list):
            return payload["results"]
        if isinstance(payload.get("risk_vectors"), list):
            return payload["risk_vectors"]
        for v in payload.values():
            if isinstance(v, list):
                return v
    return []

def fetch_all():
    session = requests.Session()
    session.auth = (ACCESS_KEY, SECRET_KEY)
    session.headers.update({"Accept": "application/json"})
    session.proxies.update(PROXIES)

    url = API_BASE.rstrip("/") + "/" + ENDPOINT.lstrip("/")
    total = 0
    rows = []
    while True:
        r = session.get(url, timeout=60)
        r.raise_for_status()
        data = r.json()
        page = extract_rows(data)
        rows.extend(page)
        total += len(page)
        nxt = get_next_link(data, API_BASE)
        if not nxt:
            break
        url = nxt
    logging.info("Risk vectors retrieved: %d", total)
    print(f"Risk vectors retrieved: {total}")
    return rows

def write_csv(path, records):
    if not records:
        with open(path, "w", newline="", encoding="utf-8") as f:
            pass
        return 0
    header = {}
    flats = []
    for rec in tqdm(records, desc="Flattening risk vectors"):
        fr = flatten(rec)
        flats.append(fr)
        for k in fr.keys():
            header.setdefault(k, None)
    fieldnames = list(header.keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for fr in flats:
            w.writerow({k: fr.get(k, "") for k in fieldnames})
    return len(flats)

def main():
    start = time.time()
    logging.info("=== risk_vectors.py start ===")
    print("risk_vectors.py starting…")
    data = fetch_all()
    written = write_csv(OUTPUT_FILE, data)
    logging.info("CSV written: %s (%d rows)", OUTPUT_FILE, written)
    print(f"{OUTPUT_FILE} written ({written} rows)")
    end = time.time()
    logging.info("=== risk_vectors.py complete in %.2f seconds ===", end - start)
    print(f"Done in {end - start:.2f}s. Log: risk_vectors.log")

if __name__ == "__main__":
    main()
